"""Fabric CLI Wrapper - Thin Wrapper Component 2/5."""

from __future__ import annotations

import base64
import json
import logging
import os
import re
import subprocess
import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import requests
from packaging import version

from usf_fabric_cli.exceptions import (
    FabricCLIError,
    FabricCLINotFoundError,
    FabricTelemetryError,
)

# Re-export retry utilities for backwards compatibility
from usf_fabric_cli.utils.retry import calculate_backoff  # noqa: F401
from usf_fabric_cli.utils.retry import (  # noqa: F401
    is_retryable_error,
    retry_with_backoff,
)
from usf_fabric_cli.utils.telemetry import TelemetryClient

if TYPE_CHECKING:
    from usf_fabric_cli.services.token_manager import TokenManager

logger = logging.getLogger(__name__)

# Expected CLI version range (can be configured)
MINIMUM_CLI_VERSION = "1.0.0"
RECOMMENDED_CLI_VERSION = "1.3.1"

# Substrings (lowercased) that indicate idempotent "already exists" errors.
# Centralised here so new patterns only need adding in one place.
IDEMPOTENT_ERROR_PATTERNS: tuple[str, ...] = (
    "already exists",
    "duplicate",
    "already has a role assigned",
    "an item with the same name exists",
)

# -- Power BI API constants for workspace deletion fallback ---------
# The Fabric REST API (api.fabric.microsoft.com) and the `fab rm` CLI
# command can return transient ``UnknownError`` responses when deleting
# workspaces.  The Power BI REST API (api.powerbi.com) is more
# reliable for workspace deletion (same pattern as pipeline user
# management).
PBI_API_BASE_URL = "https://api.powerbi.com/v1.0/myorg"
PBI_TOKEN_SCOPE = "https://analysis.windows.net/powerbi/api/.default"  # nosec B105


class FabricCLIWrapper:
    """Thin wrapper around Fabric CLI with idempotency and error handling."""

    def __init__(
        self,
        fabric_token: str,
        telemetry_client: Optional[TelemetryClient] = None,
        validate_version: bool = True,
        min_version: Optional[str] = None,
        token_manager: Optional["TokenManager"] = None,
    ):
        self.fabric_token = fabric_token
        self.telemetry = telemetry_client or TelemetryClient()
        self._last_command: List[str] | None = None
        self.cli_version: Optional[str] = None
        self.min_version = min_version or MINIMUM_CLI_VERSION
        self._token_manager = token_manager
        # Cache workspace name -> ID to avoid fab CLI lookup failures
        # after REST API-based workspace creation
        self._workspace_id_cache: Dict[str, str] = {}

        # Validate CLI version if requested
        if validate_version:
            self._validate_cli_version()

        self._setup_auth()

    def _validate_cli_version(self) -> None:
        """
        Validate that the installed Fabric CLI version meets minimum requirements.

        This addresses Gap A: Dependency on External CLI by ensuring version
        compatibility.
        """
        try:
            result = subprocess.run(
                ["fab", "--version"],
                capture_output=True,
                text=True,
                check=True,
                timeout=10,
            )

            # Parse version from output (e.g., "Fabric CLI 1.2.3" or just "1.2.3")
            version_output = result.stdout.strip()
            version_match = re.search(r"(\d+\.\d+\.\d+)", version_output)

            if version_match:
                self.cli_version = version_match.group(1)
                logger.info("Detected Fabric CLI version: %s", self.cli_version)

                # Compare versions
                try:
                    if version.parse(self.cli_version) < version.parse(
                        self.min_version
                    ):
                        logger.warning(
                            "Fabric CLI version %s is below minimum "
                            "required version %s. This may cause "
                            "compatibility issues.",
                            self.cli_version,
                            self.min_version,
                        )
                        logger.warning(
                            "Recommended version: %s",
                            RECOMMENDED_CLI_VERSION,
                        )
                except (ValueError, TypeError) as e:
                    logger.debug("Could not compare versions: %s", e)
            else:
                logger.warning("Could not parse CLI version from: %s", version_output)
                self.cli_version = "unknown"

        except FileNotFoundError:
            error_msg = (
                "Fabric CLI ('fab' command) not found. Please install it:\n"
                "  pip install ms-fabric-cli\n"
                "Or see: https://github.com/microsoft/fabric-cli"
            )
            logger.error(error_msg)
            raise FabricCLINotFoundError(["fab", "--version"]) from None

        except subprocess.TimeoutExpired:
            logger.warning("Fabric CLI version check timed out")
            self.cli_version = "unknown"

        except (OSError, RuntimeError) as e:
            logger.warning("Could not validate CLI version: %s", e)
            self.cli_version = "unknown"

    def _setup_auth(self):
        """Setup Fabric CLI authentication"""
        # We rely on explicit login with Service Principal if credentials are available.
        # This ensures the CLI has a valid token in its cache.

        client_id = os.getenv("AZURE_CLIENT_ID")
        client_secret = os.getenv("AZURE_CLIENT_SECRET")
        tenant_id = os.getenv("TENANT_ID") or os.getenv("AZURE_TENANT_ID")

        # Sanitize credentials to handle inline comments in .env files
        # Docker's --env-file includes inline comments in the value
        if client_id:
            client_id = client_id.split(" #")[0].strip()
        if client_secret:
            client_secret = client_secret.split(" #")[0].strip()
        if tenant_id:
            tenant_id = tenant_id.split(" #")[0].strip()

        if client_id and client_secret and tenant_id:
            try:
                logger.info(
                    "Attempting to login to Fabric CLI with Service Principal..."
                )

                # Enable plaintext token fallback for CI/CD environments
                # (GitHub Actions runners lack a desktop keyring)
                try:
                    subprocess.run(
                        ["fab", "config", "set", "encryption_fallback_enabled", "true"],
                        capture_output=True,
                        check=False,
                    )
                except (subprocess.SubprocessError, OSError) as e:
                    logger.debug("Config set failed (non-fatal): %s", e)

                # Logout first to clear any stale state
                try:
                    subprocess.run(
                        ["fab", "auth", "logout"], capture_output=True, check=False
                    )
                except (subprocess.SubprocessError, OSError) as e:
                    logger.debug("Auth logout failed (non-fatal): %s", e)

                # Secure credential passing via stdin python script
                # Inject credentials via env vars (hidden from process args)
                import sys  # ensure sys is locally available

                secure_script = """
import sys
import os
from fabric_cli.main import main

sys.argv = [
    'fab', 'auth', 'login',
    '--username', os.environ['FAB_CLIENT_ID'],
    '--password', os.environ['FAB_CLIENT_SECRET'],
    '--tenant', os.environ['FAB_TENANT_ID']
]
sys.exit(main())
"""
                secure_env = os.environ.copy()
                secure_env["FAB_CLIENT_ID"] = client_id
                secure_env["FAB_CLIENT_SECRET"] = client_secret
                secure_env["FAB_TENANT_ID"] = tenant_id

                # We use subprocess directly here to avoid infinite recursion if we
                # used _run_fabric_command
                cmd = [sys.executable, "-"]

                subprocess.run(
                    cmd,
                    input=secure_script,
                    capture_output=True,
                    text=True,
                    check=True,
                    env=secure_env,
                )
                logger.info("Successfully logged in to Fabric CLI")
            except subprocess.CalledProcessError as e:
                # Redact the secret from any error output before logging
                stderr = e.stderr or ""
                safe_stderr = stderr.replace(client_secret, "***REDACTED***")
                logger.error("Failed to login to Fabric CLI: %s", safe_stderr)
                # We don't raise here, as we might still be able to run if there's an
                # existing token,
                # although unlikely if explicit login failed.

    def _emit_telemetry(
        self, event: str, command: List[str], duration: float, **extra: Any
    ) -> None:
        try:
            self.telemetry.emit(
                event=event,
                command=" ".join(command),
                duration_ms=round(duration * 1000, 2),
                **extra,
            )
        except FabricTelemetryError as exc:
            logger.debug("Telemetry write failed: %s", exc)

    def _execute_command(
        self, command: List[str], check_existence: bool = False, timeout: int = 300
    ) -> Dict[str, Any]:
        try:
            return self._run_fabric_command(command, check_existence, timeout=timeout)
        except FabricCLIError as exc:
            return {"success": False, "error": str(exc), "exception": exc}

    def _run_fabric_command(
        self, command: List[str], check_existence: bool = False, timeout: int = 300
    ) -> Dict[str, Any]:
        """Execute Fabric CLI command with error handling and telemetry."""
        # Proactive token refresh for long deployments (>5 min)
        # This prevents authentication failures mid-deployment
        if self._token_manager:
            try:
                self._token_manager.ensure_fresh_auth(max_age_seconds=300)
            except (RuntimeError, ValueError) as e:
                logger.warning(
                    "Token refresh failed, continuing with existing auth: %s", e
                )

        # The Microsoft Fabric CLI command is 'fab', not 'fabric'
        full_command = ["fab"] + command
        start_time = time.time()
        self._last_command = full_command

        # Prepare environment
        env = os.environ.copy()
        # Remove SP credentials to force use of cached token from _setup_auth
        env.pop("AZURE_CLIENT_ID", None)
        env.pop("AZURE_CLIENT_SECRET", None)
        env.pop("AZURE_TENANT_ID", None)
        env.pop("TENANT_ID", None)
        env.pop("FABRIC_TOKEN", None)
        env.pop("AZURE_ACCESS_TOKEN", None)

        try:
            logger.info("Executing: %s", " ".join(full_command))
            result = subprocess.run(
                full_command,
                capture_output=True,
                text=True,
                check=True,
                env=env,
                timeout=timeout,
            )

            payload: Dict[str, Any] = {"success": True, "data": None}
            if result.stdout.strip():
                try:
                    payload["data"] = json.loads(result.stdout)
                except json.JSONDecodeError:
                    payload["data"] = result.stdout.strip()

            self._emit_telemetry(
                "fabric_cli.success",
                full_command,
                time.time() - start_time,
                reused=payload.get("reused", False),
            )
            return payload

        except subprocess.TimeoutExpired:
            error_msg = f"Command timed out after {timeout} seconds"
            self._emit_telemetry(
                "fabric_cli.timeout",
                full_command,
                time.time() - start_time,
                error=error_msg,
            )
            logger.error(error_msg)
            return {"success": False, "error": error_msg}

        except FileNotFoundError as exc:
            error = FabricCLINotFoundError(full_command)
            self._emit_telemetry(
                "fabric_cli.failure",
                full_command,
                time.time() - start_time,
                error=str(error),
            )
            logger.error("Fabric CLI binary not found: %s", exc)
            raise error from exc

        except subprocess.CalledProcessError as e:
            error_msg = e.stderr.strip() if e.stderr else ""
            output_msg = e.stdout.strip() if e.stdout else ""
            full_msg = f"{error_msg} {output_msg}"

            if check_existence and (
                any(p in full_msg.lower() for p in IDEMPOTENT_ERROR_PATTERNS)
            ):
                logger.debug("Item already exists - continuing (idempotent)")
                payload = {"success": True, "data": "already_exists", "reused": True}
                self._emit_telemetry(
                    "fabric_cli.success",
                    full_command,
                    time.time() - start_time,
                    reused=True,
                )
                return payload

            cli_error = FabricCLIError(
                full_command, e.returncode, full_msg or str(e), e.stdout
            )
            self._emit_telemetry(
                "fabric_cli.failure",
                full_command,
                time.time() - start_time,
                error=str(cli_error),
            )
            logger.error("Fabric CLI error: %s", full_msg)
            raise cli_error

    def _item_exists(self, path: str) -> bool:
        """Check if an item exists using 'fab exists'"""
        try:
            # 'fab exists' returns exit code 0 always, but prints '* true' or '* false'
            cmd = ["fab", "exists", path]
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
            return "true" in result.stdout.lower()
        except (subprocess.SubprocessError, OSError):
            return False

    def create_workspace(
        self, name: str, capacity_name: Optional[str] = None, description: str = ""
    ) -> Dict[str, Any]:
        """Create workspace with idempotency"""
        logger.debug(
            "create_workspace called with name='%s', " "capacity_name='%s'",
            name,
            capacity_name,
        )

        # Check existence first
        if self._item_exists(f"{name}.Workspace"):
            logger.info("Workspace %s already exists. Retrieving details...", name)
            workspace_info = self.get_workspace(name)
            workspace_id = None
            if workspace_info.get("success") and workspace_info.get("data"):
                data = workspace_info["data"]
                if (
                    isinstance(data, dict)
                    and "result" in data
                    and "data" in data["result"]
                    and len(data["result"]["data"]) > 0
                ):
                    workspace_id = data["result"]["data"][0].get("id")
                else:
                    workspace_id = data.get("id")

            # Cache for subsequent lookups
            if workspace_id:
                self._workspace_id_cache[name] = workspace_id

            return {
                "success": True,
                "data": "already_exists",
                "reused": True,
                "workspace_id": workspace_id,
            }

        # Check if capacity_name is a GUID
        is_guid = False
        if capacity_name:
            if re.match(
                r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
                capacity_name.lower(),
            ):
                is_guid = True

        if is_guid:
            # Use API for GUID capacity
            payload = {
                "displayName": name,
                "description": description,
                "capacityId": capacity_name,
            }

            command = ["api", "workspaces", "-X", "post", "-i", json.dumps(payload)]

            result = self._execute_command(command)

            # Check for API errors in the response
            if result.get("success") and isinstance(result.get("data"), dict):
                response_data = result["data"]
                if response_data.get("status_code", 0) >= 400:
                    error_text = response_data.get("text", {})
                    error_message = (
                        error_text.get("message")
                        if isinstance(error_text, dict)
                        else str(error_text)
                    )
                    error_code = (
                        error_text.get("errorCode")
                        if isinstance(error_text, dict)
                        else "Unknown"
                    )

                    logger.error(
                        "Error creating workspace with capacity: %s - %s",
                        error_code,
                        error_message,
                    )
                    if error_code == "InsufficientPermissionsOverCapacity":
                        logger.error(
                            "ACTION REQUIRED: The Service Principal needs 'Capacity "
                            "Admin' or 'Contributor' permissions on the Fabric "
                            "Capacity."
                        )

                    return {"success": False, "error": f"{error_code}: {error_message}"}

            if result.get("success"):
                # Check for API error in data (fab api returns 0 even on error)
                data = result.get("data")
                if isinstance(data, str):
                    try:
                        data = json.loads(data)
                    except json.JSONDecodeError as exc:
                        logger.debug(
                            "Failed to decode JSON from fabric API wrapper: %s", exc
                        )

                # Handle fab api error response format
                if isinstance(data, dict):
                    if "errorCode" in data:
                        return {
                            "success": False,
                            "error": data.get("message"),
                            "data": data,
                        }
                    if "status_code" in data and data["status_code"] >= 400:
                        error_msg = "API Error"
                        if isinstance(data.get("text"), dict):
                            error_msg = data["text"].get("message", error_msg)
                        return {"success": False, "error": error_msg, "data": data}

                # Extract ID from response
                if isinstance(data, dict) and "id" in data:
                    result["workspace_id"] = data["id"]
                else:
                    # Fallback to get_workspace
                    time.sleep(2)
                    workspace_info = self.get_workspace(name)
                    if workspace_info.get("success") and workspace_info.get("data"):
                        data = workspace_info["data"]
                        if (
                            isinstance(data, dict)
                            and "result" in data
                            and "data" in data["result"]
                            and len(data["result"]["data"]) > 0
                        ):
                            result["workspace_id"] = data["result"]["data"][0].get("id")
                        else:
                            result["workspace_id"] = data.get("id")
            # Cache the workspace ID for subsequent lookups
            if result.get("workspace_id"):
                self._workspace_id_cache[name] = result["workspace_id"]
            return result
        else:
            logger.debug("Not a GUID capacity. Using mkdir.")
            # Use 'mkdir' with -P capacityName=... (Legacy/Name-based)
            command = ["mkdir", f"{name}.Workspace"]

            if capacity_name:
                command.extend(["-P", f"capacityName={capacity_name}"])

            # Description is not directly supported by mkdir -P for workspace in CLI
            # help, but we can try to set it later if needed. For now, we skip it
            # to avoid errors.

            result = self._execute_command(command, check_existence=True)

            if result.get("success"):
                # Wait for propagation
                time.sleep(5)

                # We need to return the workspace ID for other operations
                # 'fab get name.Workspace' should return details
                workspace_info = self.get_workspace(name)
                if workspace_info.get("success") and workspace_info.get("data"):
                    data = workspace_info["data"]
                    # Handle nested structure from CLI
                    if (
                        isinstance(data, dict)
                        and "result" in data
                        and "data" in data["result"]
                        and len(data["result"]["data"]) > 0
                    ):
                        result["workspace_id"] = data["result"]["data"][0].get("id")
                    else:
                        result["workspace_id"] = data.get("id")

            # Cache the workspace ID for subsequent lookups
            if result.get("workspace_id"):
                self._workspace_id_cache[name] = result["workspace_id"]

            return result

    def get_workspace_item_summary(self, workspace_name: str) -> Dict[str, Any]:
        """Get a summary of items in a workspace for safety checks.

        Returns:
            dict with keys:
                - item_count: total number of items
                - items_by_type: dict mapping item type -> count
                - has_items: bool (True if workspace is non-empty)
                - items: list of item dicts (id, displayName, type)
        """
        items = self.list_workspace_items_api(workspace_name)
        items_by_type: Dict[str, int] = {}
        for item in items:
            item_type = item.get("type", "Unknown")
            items_by_type[item_type] = items_by_type.get(item_type, 0) + 1

        return {
            "item_count": len(items),
            "items_by_type": items_by_type,
            "has_items": len(items) > 0,
            "items": items,
        }

    def delete_workspace(self, name: str, safe: bool = False) -> Dict[str, Any]:
        """Delete workspace, with PBI API fallback.

        Attempts deletion via ``fab rm`` first.  If the Fabric CLI
        returns an ``UnknownError`` (a transient issue observed in
        production), the method falls back to the Power BI REST API
        ``DELETE /v1.0/myorg/groups/{workspaceId}`` which is more
        reliable.

        Args:
            name: Workspace display name.
            safe: If True, refuse to delete workspaces that contain
                  Fabric items (lakehouses, notebooks, pipelines, etc.).
                  This protects populated workspaces from accidental
                  deletion.  Use ``safe=False`` (default) or the CLI
                  ``--force-destroy-populated`` flag to override.
        """
        if safe:
            summary = self.get_workspace_item_summary(name)
            if summary["has_items"]:
                type_list = ", ".join(
                    f"{v}x {k}" for k, v in summary["items_by_type"].items()
                )
                return {
                    "success": False,
                    "error": (
                        f"SAFETY: Workspace '{name}' contains "
                        f"{summary['item_count']} item(s) ({type_list}). "
                        "Refusing to delete a populated workspace. "
                        "Use --force-destroy-populated to override."
                    ),
                    "blocked_by_safety": True,
                    "item_summary": summary,
                }

        # -- Primary: fab rm ----------------------------------------
        command = ["rm", f"{name}.Workspace", "--force"]
        result = self._execute_command(command)

        if result.get("success"):
            return result

        # -- Fallback: PBI REST API ---------------------------------
        # The Fabric CLI can return UnknownError on workspace deletion
        # even though the workspace exists and the SP has admin access.
        # The PBI API (DELETE /groups/{id}) is more reliable.
        error_str = str(result.get("error", ""))
        if "UnknownError" in error_str or "unexpected error" in error_str.lower():
            logger.warning(
                "fab rm failed with UnknownError for '%s'; "
                "falling back to Power BI REST API",
                name,
            )
            fallback = self._delete_workspace_pbi_api(name)
            if fallback.get("success"):
                return fallback
            # If fallback also fails, return original error with
            # fallback details appended
            fallback_err = fallback.get("error", "unknown")
            result["error"] = (
                f"{error_str} | PBI API fallback also failed: {fallback_err}"
            )

        return result

    def _get_pbi_token(self) -> str:
        """Acquire a Power BI-scoped token for REST API calls.

        Uses the TokenManager credential (same Service Principal,
        different resource scope).  Falls back to the Fabric token.
        """
        if (
            self._token_manager
            and hasattr(self._token_manager, "_credential")
            and self._token_manager._credential is not None
        ):
            try:
                access_token = self._token_manager._credential.get_token(
                    PBI_TOKEN_SCOPE
                )
                logger.debug("Acquired PBI token for workspace deletion fallback")
                return access_token.token
            except (ValueError, RuntimeError) as exc:
                logger.warning(
                    "Could not acquire PBI token (%s); " "falling back to Fabric token",
                    exc,
                )
        return self.fabric_token

    def _delete_workspace_pbi_api(self, name: str) -> Dict[str, Any]:
        """Delete a workspace via the Power BI REST API.

        ``DELETE https://api.powerbi.com/v1.0/myorg/groups/{workspaceId}``

        Args:
            name: Workspace display name (resolved to ID via cache or
                  ``get_workspace_id``).

        Returns:
            Standard result dict (``success``, ``error``).
        """
        workspace_id = self.get_workspace_id(name)
        if not workspace_id:
            return {
                "success": False,
                "error": (
                    f"Cannot resolve workspace ID for '{name}' -- "
                    "PBI API fallback requires a workspace ID"
                ),
            }

        token = self._get_pbi_token()
        headers = {
            "Authorization": f"Bearer {token}",
        }
        url = f"{PBI_API_BASE_URL}/groups/{workspace_id}"

        try:
            response = requests.delete(url, headers=headers, timeout=30)
            if response.status_code in (200, 204):
                logger.info(
                    "Workspace '%s' (%s) deleted via PBI API",
                    name,
                    workspace_id,
                )
                # Clear cache
                self._workspace_id_cache.pop(name, None)
                return {"success": True, "data": None, "method": "pbi_api"}
            else:
                body = response.text[:500]
                logger.error(
                    "PBI API delete failed for '%s': %s %s",
                    name,
                    response.status_code,
                    body,
                )
                return {
                    "success": False,
                    "error": (
                        f"PBI API DELETE /groups/{workspace_id} "
                        f"returned {response.status_code}: {body}"
                    ),
                }
        except requests.RequestException as exc:
            logger.error("PBI API request failed for '%s': %s", name, exc)
            return {"success": False, "error": f"PBI API request failed: {exc}"}

    def get_workspace(self, name: str) -> Dict[str, Any]:
        """Get workspace by name"""
        command = ["get", f"{name}.Workspace", "-q", ".", "--output_format", "json"]
        return self._execute_command(command)

    def get_workspace_id(self, name: str) -> Optional[str]:
        """Helper to get workspace ID"""
        # Check cache first (populated after REST API-based workspace creation)
        if name in self._workspace_id_cache:
            return self._workspace_id_cache[name]

        workspace_info = self.get_workspace(name)
        if workspace_info.get("success") and workspace_info.get("data"):
            data = workspace_info["data"]
            if (
                isinstance(data, dict)
                and "result" in data
                and "data" in data["result"]
                and len(data["result"]["data"]) > 0
            ):
                return data["result"]["data"][0].get("id")
            else:
                return data.get("id")
        return None

    def _list_all_folders_raw(self, workspace_name: str) -> List[Dict[str, str]]:
        """List all folders in workspace, preserving hierarchy info.

        Returns list of dicts with ``id``, ``displayName``, and
        ``parentFolderId`` (empty string for root-level folders).
        """
        workspace_id = self.get_workspace_id(workspace_name)
        if not workspace_id:
            return []

        command = ["api", f"workspaces/{workspace_id}/folders"]
        result = self._execute_command(command)

        if not result.get("success"):
            return []

        data = result.get("data")
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except json.JSONDecodeError:
                return []

        # Handle nested "text" field from fab api wrapper
        if isinstance(data, dict) and "text" in data and isinstance(data["text"], dict):
            data = data["text"]

        if not isinstance(data, dict) or "value" not in data:
            return []

        return [
            {
                "id": f.get("id", ""),
                "displayName": f.get("displayName", ""),
                "parentFolderId": f.get("parentFolderId", ""),
            }
            for f in data["value"]
        ]

    @staticmethod
    def _build_folder_path_lookup(
        raw_folders: List[Dict[str, str]],
    ) -> Dict[str, str]:
        """Build a mapping from path strings to folder IDs.

        Reconstructs folder hierarchy from ``parentFolderId`` and produces
        path-based keys using ``/`` as separator.

        Example::

            Input:  [{"id": "a", "displayName": "200 Store", "parentFolderId": ""},
                     {"id": "b", "displayName": "Raw", "parentFolderId": "a"}]
            Output: {"200 Store": "a", "200 Store/Raw": "b"}

        Root-level folders use their ``displayName`` as the path key.
        """
        id_to_folder: Dict[str, Dict[str, str]] = {
            f["id"]: f for f in raw_folders if f.get("id")
        }
        path_cache: Dict[str, str] = {}  # folder_id -> resolved path

        def _resolve_path(folder_id: str) -> str:
            if folder_id in path_cache:
                return path_cache[folder_id]
            folder = id_to_folder.get(folder_id)
            if not folder:
                return ""
            parent_id = folder.get("parentFolderId", "")
            if parent_id and parent_id in id_to_folder:
                parent_path = _resolve_path(parent_id)
                path = f"{parent_path}/{folder['displayName']}"
            else:
                path = folder["displayName"]
            path_cache[folder_id] = path
            return path

        lookup: Dict[str, str] = {}
        for f in raw_folders:
            fid = f.get("id", "")
            if fid:
                path = _resolve_path(fid)
                if path:
                    lookup[path] = fid
        return lookup

    def get_folder_id(
        self, workspace_name: str, folder_name: str, retries: int = 5
    ) -> Optional[str]:
        """Get folder ID by name or path with retries for propagation.

        Supports both flat names (``"200 Store"``) and path-based names
        (``"200 Store/Raw"``).
        """
        folder_name = folder_name.strip("/")
        if not folder_name:
            return None

        for attempt in range(retries):
            raw = self._list_all_folders_raw(workspace_name)
            if raw:
                lookup = self._build_folder_path_lookup(raw)
                folder_id = lookup.get(folder_name)
                if folder_id:
                    return folder_id

            # Wait before retrying if not found
            if attempt < retries - 1:
                time.sleep(2)

        return None

    def create_folder(self, workspace_name: str, folder_name: str) -> Dict[str, Any]:
        """Create folder in workspace, supporting nested paths.

        For path-based names like ``"200 Store/Raw"``, the parent folder
        is resolved (or auto-created) and ``parentFolderId`` is included
        in the POST payload.  Flat names behave identically to before.
        """
        folder_name = folder_name.strip("/")
        if not folder_name:
            return {"success": False, "error": "Empty folder name"}

        # Check if already exists
        folder_id = self.get_folder_id(workspace_name, folder_name, retries=1)
        if folder_id:
            logger.info("Folder %s already exists.", folder_name)
            return {
                "success": True,
                "data": "already_exists",
                "reused": True,
                "id": folder_id,
            }

        workspace_id = self.get_workspace_id(workspace_name)
        if not workspace_id:
            return {"success": False, "error": f"Workspace {workspace_name} not found"}

        parts = folder_name.split("/")
        leaf_name = parts[-1]
        parent_folder_id = None

        # Resolve or auto-create parent for nested paths
        if len(parts) > 1:
            parent_path = "/".join(parts[:-1])
            parent_folder_id = self.get_folder_id(
                workspace_name, parent_path, retries=1
            )
            if not parent_folder_id:
                logger.info(
                    "Auto-creating parent folder '%s' for '%s'",
                    parent_path,
                    folder_name,
                )
                parent_result = self.create_folder(workspace_name, parent_path)
                if parent_result.get("success"):
                    parent_folder_id = parent_result.get("id")
                    if not parent_folder_id:
                        parent_folder_id = self.get_folder_id(
                            workspace_name, parent_path, retries=2
                        )
                if not parent_folder_id:
                    return {
                        "success": False,
                        "error": (
                            f"Could not resolve parent folder '{parent_path}' "
                            f"for '{folder_name}'"
                        ),
                    }

        # Build payload
        payload: Dict[str, str] = {"displayName": leaf_name}
        if parent_folder_id:
            payload["parentFolderId"] = parent_folder_id

        command = [
            "api",
            f"workspaces/{workspace_id}/folders",
            "-X",
            "post",
            "-i",
            json.dumps(payload),
        ]
        return self._execute_command(command)

    def create_lakehouse(
        self,
        workspace_name: str,
        name: str,
        description: str = "",
        folder: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create lakehouse"""
        if folder:
            folder_id = self.get_folder_id(workspace_name, folder)
            if not folder_id:
                logger.warning(
                    "Folder %s not found. Creating Lakehouse %s at root.",
                    folder,
                    name,
                )
                folder_id = None
        else:
            folder_id = None

        if folder_id:
            workspace_id = self.get_workspace_id(workspace_name)
            if not workspace_id:
                return {
                    "success": False,
                    "error": f"Workspace {workspace_name} not found",
                }

            payload = {
                "displayName": name,
                "type": "Lakehouse",
                "description": description,
                "folderId": folder_id,
            }

            command = [
                "api",
                f"workspaces/{workspace_id}/items",
                "-X",
                "post",
                "-i",
                json.dumps(payload),
            ]
            return self._execute_command(command)
        else:
            # Try REST API first (avoids fab CLI path-resolution issues)
            workspace_id = self.get_workspace_id(workspace_name)
            if workspace_id:
                payload = {
                    "displayName": name,
                    "type": "Lakehouse",
                    "description": description,
                }
                command = [
                    "api",
                    f"workspaces/{workspace_id}/items",
                    "-X",
                    "post",
                    "-i",
                    json.dumps(payload),
                ]
                return self._execute_command(command, check_existence=True)
            # Fallback to fab mkdir
            path = f"{workspace_name}.Workspace/{name}.Lakehouse"
            if self._item_exists(path):
                return {"success": True, "data": "already_exists", "reused": True}
            command = ["mkdir", path]
            return self._execute_command(command, check_existence=True)

    def create_warehouse(
        self,
        workspace_name: str,
        name: str,
        description: str = "",
        folder: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create warehouse"""
        if folder:
            folder_id = self.get_folder_id(workspace_name, folder)
            if not folder_id:
                logger.warning(
                    "Folder %s not found. Creating Warehouse %s at root.",
                    folder,
                    name,
                )
                folder_id = None
        else:
            folder_id = None

        if folder_id:
            workspace_id = self.get_workspace_id(workspace_name)
            if not workspace_id:
                return {
                    "success": False,
                    "error": f"Workspace {workspace_name} not found",
                }

            payload = {
                "displayName": name,
                "type": "Warehouse",
                "description": description,
                "folderId": folder_id,
            }

            command = [
                "api",
                f"workspaces/{workspace_id}/items",
                "-X",
                "post",
                "-i",
                json.dumps(payload),
            ]
            return self._execute_command(command)
        else:
            # Try REST API first (avoids fab CLI path-resolution issues)
            workspace_id = self.get_workspace_id(workspace_name)
            if workspace_id:
                payload = {
                    "displayName": name,
                    "type": "Warehouse",
                    "description": description,
                }
                command = [
                    "api",
                    f"workspaces/{workspace_id}/items",
                    "-X",
                    "post",
                    "-i",
                    json.dumps(payload),
                ]
                return self._execute_command(command, check_existence=True)
            # Fallback to fab mkdir
            path = f"{workspace_name}.Workspace/{name}.Warehouse"
            if self._item_exists(path):
                return {"success": True, "data": "already_exists", "reused": True}
            command = ["mkdir", path]
            return self._execute_command(command, check_existence=True)

    def _read_notebook_definition(self, file_path: str) -> Optional[str]:
        """Read notebook file and return base64-encoded content for Fabric API.

        Supports .py (converted to single-cell .ipynb) and .ipynb files.

        Args:
            file_path: Path to notebook source file

        Returns:
            Base64-encoded notebook content, or None if file not found
        """
        from pathlib import Path

        path = Path(file_path)
        if not path.exists():
            # Try relative to config file directory
            logger.warning("Notebook file not found: %s", file_path)
            return None

        try:
            content = path.read_text(encoding="utf-8")

            if path.suffix == ".py":
                # Wrap Python content in minimal .ipynb structure
                notebook_json = json.dumps(
                    {
                        "nbformat": 4,
                        "nbformat_minor": 5,
                        "metadata": {
                            "language_info": {"name": "python"},
                            "kernel_info": {"name": "synapse_pyspark"},
                        },
                        "cells": [
                            {
                                "cell_type": "code",
                                "source": content,
                                "metadata": {},
                                "outputs": [],
                            }
                        ],
                    }
                )
                return base64.b64encode(notebook_json.encode("utf-8")).decode("utf-8")
            elif path.suffix == ".ipynb":
                return base64.b64encode(content.encode("utf-8")).decode("utf-8")
            else:
                logger.warning(
                    "Unsupported notebook file type: %s. " "Supported: .py, .ipynb",
                    path.suffix,
                )
                return None
        except OSError as e:
            logger.error("Failed to read notebook file %s: %s", file_path, e)
            return None

    def create_notebook(
        self,
        workspace_name: str,
        name: str,
        file_path: Optional[str] = None,
        folder: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create notebook, optionally importing content from file_path."""
        # Read notebook content if file_path is provided
        notebook_definition = None
        if file_path:
            notebook_definition = self._read_notebook_definition(file_path)
            if notebook_definition:
                logger.info("Loaded notebook content from %s", file_path)
            else:
                logger.warning(
                    "Could not load notebook from %s; " "creating empty notebook",
                    file_path,
                )

        if folder:
            folder_id = self.get_folder_id(workspace_name, folder)
            if not folder_id:
                logger.warning(
                    "Folder %s not found. Creating Notebook %s at root.",
                    folder,
                    name,
                )
                folder_id = None
        else:
            folder_id = None

        if folder_id:
            workspace_id = self.get_workspace_id(workspace_name)
            if not workspace_id:
                return {
                    "success": False,
                    "error": f"Workspace {workspace_name} not found",
                }

            payload: Dict[str, Any] = {
                "displayName": name,
                "type": "Notebook",
                "folderId": folder_id,
            }

            if notebook_definition:
                payload["definition"] = {
                    "format": "ipynb",
                    "parts": [
                        {
                            "path": "notebook-content.py",
                            "payload": notebook_definition,
                            "payloadType": "InlineBase64",
                        }
                    ],
                }

            command = [
                "api",
                f"workspaces/{workspace_id}/items",
                "-X",
                "post",
                "-i",
                json.dumps(payload),
            ]
            return self._execute_command(command)
        else:
            # Try REST API first (avoids fab CLI path-resolution issues)
            workspace_id = self.get_workspace_id(workspace_name)
            if workspace_id:
                payload = {  # type: ignore[no-redef]
                    "displayName": name,
                    "type": "Notebook",
                }

                if notebook_definition:
                    payload["definition"] = {
                        "format": "ipynb",
                        "parts": [
                            {
                                "path": "notebook-content.py",
                                "payload": notebook_definition,
                                "payloadType": "InlineBase64",
                            }
                        ],
                    }

                command = [
                    "api",
                    f"workspaces/{workspace_id}/items",
                    "-X",
                    "post",
                    "-i",
                    json.dumps(payload),
                ]
                return self._execute_command(command, check_existence=True)
            # Fallback to fab mkdir
            path = f"{workspace_name}.Workspace/{name}.Notebook"
            if self._item_exists(path):
                return {"success": True, "data": "already_exists", "reused": True}
            command = ["mkdir", path]
            return self._execute_command(command, check_existence=True)

    def create_pipeline(
        self,
        workspace_name: str,
        name: str,
        description: str = "",
        folder: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create data pipeline"""
        if folder:
            folder_id = self.get_folder_id(workspace_name, folder)
            if not folder_id:
                logger.warning(
                    "Folder %s not found. Creating Pipeline %s at root.",
                    folder,
                    name,
                )
                folder_id = None
        else:
            folder_id = None

        if folder_id:
            workspace_id = self.get_workspace_id(workspace_name)
            if not workspace_id:
                return {
                    "success": False,
                    "error": f"Workspace {workspace_name} not found",
                }

            payload = {
                "displayName": name,
                "type": "DataPipeline",
                "description": description,
                "folderId": folder_id,
            }

            command = [
                "api",
                f"workspaces/{workspace_id}/items",
                "-X",
                "post",
                "-i",
                json.dumps(payload),
            ]
            return self._execute_command(command)
        else:
            workspace_id = self.get_workspace_id(workspace_name)
            if workspace_id:
                payload = {
                    "displayName": name,
                    "type": "DataPipeline",
                    "description": description,
                }
                command = [
                    "api",
                    f"workspaces/{workspace_id}/items",
                    "-X",
                    "post",
                    "-i",
                    json.dumps(payload),
                ]
                return self._execute_command(command, check_existence=True)
            path = f"{workspace_name}.Workspace/{name}.DataPipeline"
            if self._item_exists(path):
                return {"success": True, "data": "already_exists", "reused": True}
            command = ["mkdir", path]
            return self._execute_command(command, check_existence=True)

    def create_semantic_model(
        self,
        workspace_name: str,
        name: str,
        description: str = "",
        folder: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create semantic model"""
        if folder:
            folder_id = self.get_folder_id(workspace_name, folder)
            if not folder_id:
                logger.warning(
                    "Folder %s not found. Creating SemanticModel %s at root.",
                    folder,
                    name,
                )
                folder_id = None
        else:
            folder_id = None

        if folder_id:
            workspace_id = self.get_workspace_id(workspace_name)
            if not workspace_id:
                return {
                    "success": False,
                    "error": f"Workspace {workspace_name} not found",
                }

            payload = {
                "displayName": name,
                "type": "SemanticModel",
                "description": description,
                "folderId": folder_id,
            }

            command = [
                "api",
                f"workspaces/{workspace_id}/items",
                "-X",
                "post",
                "-i",
                json.dumps(payload),
            ]
            return self._execute_command(command)
        else:
            workspace_id = self.get_workspace_id(workspace_name)
            if workspace_id:
                payload = {
                    "displayName": name,
                    "type": "SemanticModel",
                    "description": description,
                }
                command = [
                    "api",
                    f"workspaces/{workspace_id}/items",
                    "-X",
                    "post",
                    "-i",
                    json.dumps(payload),
                ]
                return self._execute_command(command, check_existence=True)
            path = f"{workspace_name}.Workspace/{name}.SemanticModel"
            if self._item_exists(path):
                return {"success": True, "data": "already_exists", "reused": True}
            command = ["mkdir", path]
            return self._execute_command(command, check_existence=True)

    def create_item(
        self,
        workspace_name: str,
        name: str,
        item_type: str,
        description: str = "",
        folder: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create any generic Fabric item (Future-proof)"""
        if folder:
            folder_id = self.get_folder_id(workspace_name, folder)
            if not folder_id:
                logger.warning(
                    "Folder %s not found. Creating %s %s at root.",
                    folder,
                    item_type,
                    name,
                )
                folder_id = None
        else:
            folder_id = None

        if folder_id:
            workspace_id = self.get_workspace_id(workspace_name)
            if not workspace_id:
                return {
                    "success": False,
                    "error": f"Workspace {workspace_name} not found",
                }

            payload = {
                "displayName": name,
                "type": item_type,
                "description": description,
                "folderId": folder_id,
            }

            command = [
                "api",
                f"workspaces/{workspace_id}/items",
                "-X",
                "post",
                "-i",
                json.dumps(payload),
            ]
            return self._execute_command(command)
        else:
            workspace_id = self.get_workspace_id(workspace_name)
            if workspace_id:
                payload = {
                    "displayName": name,
                    "type": item_type,
                    "description": description,
                }
                command = [
                    "api",
                    f"workspaces/{workspace_id}/items",
                    "-X",
                    "post",
                    "-i",
                    json.dumps(payload),
                ]
                return self._execute_command(command, check_existence=True)
            path = f"{workspace_name}.Workspace/{name}.{item_type}"
            if self._item_exists(path):
                return {"success": True, "data": "already_exists", "reused": True}
            command = ["mkdir", path]
            return self._execute_command(command, check_existence=True)

    def add_workspace_principal(
        self, workspace_name: str, principal_id: str, role: str = "Member"
    ) -> Dict[str, Any]:
        """Add principal (user/service principal) to workspace"""
        # Skip empty or placeholder emails
        if not principal_id:
            # Silent skip for empty ID (handled by config warning)
            return {
                "success": True,
                "message": "Skipped empty principal",
                "skipped": True,
            }

        if "your-company.com" in principal_id or "example.com" in principal_id:
            logger.warning("Skipping placeholder principal: %s", principal_id)
            return {
                "success": True,
                "message": "Skipped placeholder principal",
                "skipped": True,
            }

        # Skip if principal_id matches the deploying SP's Client ID
        # (the SP already has implicit Admin access as workspace creator)
        sp_client_id = os.environ.get("AZURE_CLIENT_ID", "")
        if sp_client_id and principal_id.lower() == sp_client_id.lower():
            logger.info(
                "Skipping deploying SP Client ID %s... "
                "(already has implicit Admin access as workspace creator)",
                principal_id[:12],
            )
            return {
                "success": True,
                "message": "Deploying SP already has implicit Admin access",
                "skipped": True,
            }

        # Check if principal_id looks like an email
        if "@" in principal_id and not re.match(
            r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
            principal_id.lower(),
        ):
            logger.warning(
                "Principal ID '%s' looks like an email. Fabric CLI/API "
                "requires an Object ID (GUID).",
                principal_id,
            )
            # We continue anyway, as the CLI might support it in future or if it's a
            # UPN that works in some contexts
            # But we log a warning.

        # Use direct REST API for role assignment (avoids fab CLI issues)
        workspace_id = self.get_workspace_id(workspace_name)
        if workspace_id:
            # Map role names to Fabric API values
            role_map = {
                "Admin": "Admin",
                "Member": "Member",
                "Contributor": "Contributor",
                "Viewer": "Viewer",
            }
            api_role = role_map.get(role, role)

            # Try principal types in order: User -> ServicePrincipal -> Group
            principal_types_to_try = ["User", "ServicePrincipal", "Group"]
            last_error = ""

            for ptype in principal_types_to_try:
                # Fabric API expects nested format:
                # {"principal": {"id": "...", "type": "..."}, "role": "..."}
                payload = {
                    "principal": {
                        "id": principal_id,
                        "type": ptype,
                    },
                    "role": api_role,
                }

                try:
                    import requests

                    # Get fresh token
                    token = self.fabric_token
                    if self._token_manager:
                        try:
                            token = self._token_manager.get_token()
                        except (ValueError, RuntimeError) as token_err:
                            logger.debug("Failed to get fresh token: %s", token_err)

                    headers = {
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                    }
                    url = (
                        f"https://api.fabric.microsoft.com/v1/"
                        f"workspaces/{workspace_id}/roleAssignments"
                    )
                    resp = requests.post(url, headers=headers, json=payload, timeout=30)

                    if resp.status_code == 201:
                        logger.info(
                            "Added principal %s... as %s/%s",
                            principal_id[:12],
                            ptype,
                            api_role,
                        )
                        return {"success": True, "data": resp.json()}

                    if resp.status_code == 409:
                        # Already has a role assigned
                        return {
                            "success": True,
                            "data": "already_exists",
                            "reused": True,
                        }

                    # Parse error response
                    try:
                        err_body = resp.json()
                        error_code = err_body.get("errorCode", "")
                        error_msg = err_body.get("message", resp.text)
                        # Check nested moreDetails for specific errors
                        more_details = err_body.get("moreDetails", [])
                        detail_msgs = [d.get("message", "") for d in more_details]
                        last_error = (
                            f"{error_code}: {error_msg} "
                            f"{'; '.join(detail_msgs)}".strip()
                        )
                    except (ValueError, KeyError, TypeError) as parse_err:
                        last_error = (
                            f"HTTP {resp.status_code}:"
                            f" {resp.text} (Parse error: {parse_err})"
                        )

                    # Only retry with next type if principal type issue
                    if not any(
                        kw in last_error
                        for kw in [
                            "PrincipalNotFound",
                            "InvalidPrincipalType",
                            "PrincipalTypeNotSupported",
                            "does not exist in tenant",
                        ]
                    ):
                        break  # Non-type-related error, don't retry

                except (
                    requests.exceptions.RequestException,
                    ValueError,
                    TypeError,
                ) as e:
                    last_error = str(e)
                    logger.error(
                        "REST API call failed for principal " "%s...: %s",
                        principal_id[:12],
                        e,
                    )
                    break

            # All types exhausted or non-retryable error
            return {"success": False, "error": last_error}
        else:
            # Fallback to fab acl set if workspace ID not available
            command = [
                "acl",
                "set",
                f"{workspace_name}.Workspace",
                "--identity",
                principal_id,
                "--role",
                role,
                "--force",
            ]
            result = self._execute_command(command, check_existence=True)

        if not result.get("success"):
            error_msg = result.get("error", "")
            if "NotFound" in error_msg or "identity not found" in error_msg:
                logger.error(
                    "Principal ID %s not found. Please verify the Object "
                    "ID and ensure it exists in the tenant.",
                    principal_id,
                )
                # Return success=True to avoid failing the entire deployment for one
                # missing user
                return {
                    "success": True,
                    "message": f"Principal {principal_id} not found (skipped)",
                    "skipped": True,
                }

        return result

    def _parse_git_url(self, git_url: str) -> Dict[str, str]:
        """Parse Git URL to extract details"""
        # Azure DevOps URL formats:
        # 1. https://dev.azure.com/{org}/{project}/_git/{repo}
        # 2. https://{org}.visualstudio.com/{project}/_git/{repo}

        # Format 1 (ADO)
        match1 = re.search(
            r"https://dev\.azure\.com/([^/]+)/([^/]+)/_git/([^/]+)", git_url
        )
        if match1:
            return {
                "gitProviderType": "AzureDevOps",
                "organizationName": match1.group(1),
                "projectName": match1.group(2),
                "repositoryName": match1.group(3),
            }

        # Format 2 (ADO)
        match2 = re.search(
            r"https://([^.]+)\.visualstudio\.com/([^/]+)/_git/([^/]+)", git_url
        )
        if match2:
            return {
                "gitProviderType": "AzureDevOps",
                "organizationName": match2.group(1),
                "projectName": match2.group(2),
                "repositoryName": match2.group(3),
            }

        # GitHub URL format
        # https://github.com/{owner}/{repo}
        match3 = re.search(r"https://github\.com/([^/]+)/([^/.]+)(?:\.git)?", git_url)
        if match3:
            return {
                "gitProviderType": "GitHub",
                "ownerName": match3.group(1),
                "repositoryName": match3.group(2),
            }

        return {}

    def connect_git(
        self,
        workspace_name: str,
        git_repo: str,
        branch: str = "main",
        directory: str = "/",
    ) -> Dict[str, Any]:
        """Connect workspace to Git repository"""

        # 1. Get Workspace ID
        workspace_info = self.get_workspace(workspace_name)
        workspace_id = None
        if workspace_info.get("success") and workspace_info.get("data"):
            data = workspace_info["data"]
            if (
                isinstance(data, dict)
                and "result" in data
                and "data" in data["result"]
                and len(data["result"]["data"]) > 0
            ):
                workspace_id = data["result"]["data"][0].get("id")
            else:
                workspace_id = data.get("id")

        if not workspace_id:
            return {
                "success": False,
                "error": f"Could not find workspace ID for {workspace_name}",
            }

        # 2. Parse Git URL
        git_details = self._parse_git_url(git_repo)
        if not git_details:
            return {
                "success": False,
                "error": (
                    f"Could not parse Git URL: {git_repo}. Expected Azure DevOps or "
                    "GitHub URL."
                ),
            }

        # 3. Construct Payload
        provider_type = git_details.get("gitProviderType", "AzureDevOps")

        if provider_type == "GitHub":
            payload = {
                "gitProviderDetails": {
                    "gitProviderType": "GitHub",
                    "ownerName": git_details["ownerName"],
                    "repositoryName": git_details["repositoryName"],
                    "branchName": branch,
                    "directoryName": directory,
                }
            }
        else:
            # Azure DevOps
            payload = {
                "gitProviderDetails": {
                    "gitProviderType": "AzureDevOps",
                    "organizationName": git_details["organizationName"],
                    "projectName": git_details["projectName"],
                    "repositoryName": git_details["repositoryName"],
                    "branchName": branch,
                    "directoryName": directory,
                }
            }

        # 4. Call Fabric API
        # Endpoint: POST
        # https://api.fabric.microsoft.com/v1/workspaces/{workspaceId}/git/connect
        endpoint = f"v1/workspaces/{workspace_id}/git/connect"

        # Use 'fab api' command
        # fab api <endpoint> -X POST -i <json_string>
        command = ["api", endpoint, "-X", "post", "-i", json.dumps(payload)]

        logger.info(
            "Connecting workspace %s to Git repo %s...", workspace_name, git_repo
        )
        return self._execute_command(command)

    def assign_to_domain(self, workspace_name: str, domain_name: str) -> Dict[str, Any]:
        """Assign workspace to a domain"""
        # Command: fab assign <domain_path> -W <workspace_path>
        # Example: fab assign .domains/Sales.Domain -W SalesWorkspace.Workspace

        # Ensure domain name has .Domain suffix if not present (though CLI might
        # handle it, best to be explicit based on ls output)
        # But wait, 'fab ls .domains' output shows names like "01 Strategy... .Domain"
        # The user might provide just "Sales" or the full name.
        # Let's assume the user provides the name and we might need to find the full
        # path or just try to use it.
        # Based on 'fab assign --help', example is '.domains/domain1.Domain'

        # We'll try to construct the path if it doesn't look like a path
        domain_path = domain_name
        if not domain_path.startswith(".domains/"):
            # If it doesn't end with .Domain, append it?
            # The CLI seems to use .Domain suffix for items.
            if not domain_path.endswith(".Domain"):
                domain_path = f"{domain_path}.Domain"
            domain_path = f".domains/{domain_path}"

        command = ["assign", domain_path, "-W", f"{workspace_name}.Workspace", "-f"]

        logger.info(
            "Assigning workspace %s to domain %s...", workspace_name, domain_name
        )
        return self._execute_command(command, timeout=60)

    def list_workspace_items(self, workspace_name: str) -> Dict[str, Any]:
        """List all items in workspace"""
        command = ["ls", f"{workspace_name}.Workspace"]
        return self._execute_command(command)

    def list_workspace_items_api(self, workspace_name: str) -> List[Dict[str, Any]]:
        """List all items in workspace via REST API (structured JSON).

        Returns a list of item dicts with keys: id, displayName, type,
        folderId (if the item is inside a folder, else absent).
        """
        workspace_id = self.get_workspace_id(workspace_name)
        if not workspace_id:
            logger.warning("Could not resolve workspace ID for %s", workspace_name)
            return []

        items: List[Dict[str, Any]] = []
        url = f"workspaces/{workspace_id}/items"
        while url:
            command = ["api", url]
            result = self._execute_command(command)
            if not result.get("success"):
                logger.warning(
                    "Failed to list items for %s: %s",
                    workspace_name,
                    result.get("error"),
                )
                break
            data = result.get("data")

            # Handle string response from fab api
            if isinstance(data, str):
                try:
                    data = json.loads(data)
                except json.JSONDecodeError:
                    break

            # Handle nested "text" field from fab api wrapper
            if (
                isinstance(data, dict)
                and "text" in data
                and isinstance(data["text"], dict)
            ):
                data = data["text"]

            if isinstance(data, dict):
                items.extend(data.get("value", []))
                # Handle pagination -- prefer continuationToken (just the
                # token) over continuationUri (full URL that needs path
                # extraction).  The Fabric CLI `api` command expects a
                # relative path, not a full URL.
                continuation_token = data.get("continuationToken", "")
                continuation_uri = data.get("continuationUri", "")
                if continuation_token:
                    url = (
                        f"workspaces/{workspace_id}/items"
                        f"?continuationToken={continuation_token}"
                    )
                elif continuation_uri:
                    # Extract relative path from full URL
                    # e.g. https://api.fabric.microsoft.com/v1/workspaces/...
                    if "/v1/" in continuation_uri:
                        url = continuation_uri.split("/v1/", 1)[1]
                    else:
                        logger.warning(
                            "Unexpected continuationUri format: %s",
                            continuation_uri,
                        )
                        url = ""
                else:
                    url = ""
            else:
                break
        return items

    def move_item_to_folder(
        self,
        workspace_name: str,
        item_id: str,
        folder_id: str,
        item_name: str = "",
    ) -> Dict[str, Any]:
        """Move a workspace item into a folder using the Items - Update API.

        Uses: PATCH /workspaces/{workspaceId}/items/{itemId}
        Body: { "folderId": "<folder-guid>" }

        Args:
            workspace_name: Workspace display name.
            item_id: GUID of the item to move.
            folder_id: GUID of the target folder.
            item_name: Optional display name for logging.

        Returns:
            Standard result dict with success/error keys.
        """
        workspace_id = self.get_workspace_id(workspace_name)
        if not workspace_id:
            return {
                "success": False,
                "error": f"Could not resolve workspace ID for {workspace_name}",
            }

        payload = json.dumps({"folderId": folder_id})
        command = [
            "api",
            f"workspaces/{workspace_id}/items/{item_id}",
            "-X",
            "patch",
            "-i",
            payload,
        ]
        display = item_name or item_id[:12]
        logger.info("Moving item '%s' into folder %s", display, folder_id[:12])
        return self._execute_command(command)

    def organize_items_into_folders(
        self,
        workspace_name: str,
        folder_rules: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Move items at workspace root into designated folders.

        This is the post-Git-Sync folder organiser (Fixes TF-001).
        Fabric Git Sync always places items at the workspace root because
        folder assignments are not stored in Git metadata. This method
        reads the workspace items, identifies those at root, and moves
        them to the folder specified by the rules.

        Args:
            workspace_name: Workspace display name.
            folder_rules: List of dicts, each with:
                - ``type``: Fabric item type (e.g. "Lakehouse", "Notebook")
                - ``name``: Item display name (optional -- omit to match all
                  items of the given type)
                - ``folder``: Target folder display name

        Returns:
            Dict with ``moved``, ``skipped``, ``failed`` counts and
            ``details`` list.
        """
        result: Dict[str, Any] = {
            "moved": 0,
            "skipped": 0,
            "failed": 0,
            "details": [],
        }

        if not folder_rules:
            return result

        # Step 1: List all items via REST API
        items = self.list_workspace_items_api(workspace_name)
        if not items:
            logger.info("No items found in workspace %s", workspace_name)
            return result

        # Step 2: Build folder-path -> folder-id lookup (supports nested folders)
        raw_folders = self._list_all_folders_raw(workspace_name)
        if not raw_folders:
            result["failed"] = len(folder_rules)
            return result

        folder_lookup = self._build_folder_path_lookup(raw_folders)

        # Step 3: For each rule, find matching items at root and move them.
        # Sort rules so name-specific rules execute before wildcards of the
        # same type.  This ensures "move Notebook 'X' to folder A" runs
        # before "move all Notebooks to folder B".
        sorted_rules = sorted(
            folder_rules,
            key=lambda r: (0 if r.get("name") else 1, r.get("type", "")),
        )
        # Track items already moved to prevent double-moves when multiple
        # rules match (e.g. name-specific + wildcard for the same type).
        moved_item_ids: set = set()

        for rule in sorted_rules:
            target_type = rule.get("type", "")
            target_name = rule.get("name")  # None means "all of this type"
            target_folder = rule.get("folder", "")

            folder_id = folder_lookup.get(target_folder)
            if not folder_id:
                logger.warning(
                    "Folder '%s' not found in workspace %s -- skipping rule",
                    target_folder,
                    workspace_name,
                )
                result["failed"] += 1
                result["details"].append(
                    {
                        "item": target_name or f"all {target_type}",
                        "folder": target_folder,
                        "status": "folder_not_found",
                    }
                )
                continue

            for item in items:
                item_type = item.get("type", "")
                item_name = item.get("displayName", "")
                item_id = item.get("id", "")
                item_folder = item.get("folderId")

                # Skip items already in a folder
                if item_folder:
                    continue

                # Skip items already moved by a previous rule
                if item_id in moved_item_ids:
                    continue

                # Match by type (case-insensitive)
                if item_type.lower() != target_type.lower():
                    continue

                # If a specific name is given, match it
                if target_name and item_name != target_name:
                    continue

                # Move the item
                move_result = self.move_item_to_folder(
                    workspace_name, item_id, folder_id, item_name
                )
                if move_result.get("success"):
                    result["moved"] += 1
                    moved_item_ids.add(item_id)
                    result["details"].append(
                        {
                            "item": item_name,
                            "type": item_type,
                            "folder": target_folder,
                            "status": "moved",
                        }
                    )
                    logger.info(
                        "Moved %s '%s' -> folder '%s'",
                        item_type,
                        item_name,
                        target_folder,
                    )
                else:
                    result["failed"] += 1
                    result["details"].append(
                        {
                            "item": item_name,
                            "type": item_type,
                            "folder": target_folder,
                            "status": "failed",
                            "error": move_result.get("error", "unknown"),
                        }
                    )

        return result

    def wait_for_operation(
        self, operation_id: str, max_wait_seconds: int = 300
    ) -> bool:
        """Wait for long-running operation to complete"""
        start_time = time.time()

        while time.time() - start_time < max_wait_seconds:
            command = ["operation", "show", "--operation-id", operation_id]
            result = self._execute_command(command)

            if result.get("success") and result.get("data"):
                status = result["data"].get("status", "Unknown")
                if status in ["Succeeded", "Completed"]:
                    return True
                elif status in ["Failed", "Cancelled"]:
                    logger.error(
                        "Operation %s failed with status: %s",
                        operation_id,
                        status,
                    )
                    return False

            time.sleep(10)  # Wait 10 seconds before checking again

        logger.error(
            "Operation %s timed out after %s seconds",
            operation_id,
            max_wait_seconds,
        )
        return False


class FabricDiagnostics:
    """Diagnostic utilities for troubleshooting"""

    def __init__(self, cli_wrapper: FabricCLIWrapper):
        self.cli = cli_wrapper

    def validate_fabric_cli_installation(self) -> Dict[str, Any]:
        """Validate Fabric CLI is properly installed with version checking"""
        try:
            result = subprocess.run(
                ["fab", "--version"], capture_output=True, text=True, check=True
            )

            version_output = result.stdout.strip()

            # Enhanced validation with version compatibility check
            validation_result = {
                "success": True,
                "version": version_output,
                "message": "Fabric CLI is properly installed",
            }

            # Check if we have a parsed version from the wrapper
            if self.cli.cli_version and self.cli.cli_version != "unknown":
                validation_result["parsed_version"] = self.cli.cli_version
                validation_result["minimum_version"] = self.cli.min_version

                try:
                    current = version.parse(self.cli.cli_version)
                    minimum = version.parse(self.cli.min_version)

                    if current < minimum:
                        validation_result["warning"] = (
                            f"CLI version {self.cli.cli_version} is below minimum "
                            f"required version {self.cli.min_version}. "
                            f"Consider upgrading to {RECOMMENDED_CLI_VERSION}."
                        )
                    elif current >= minimum:
                        validation_result["compatibility"] = "compatible"

                except ValueError as ve:
                    logger.debug("Version parse error: %s", ve)

            return validation_result

        except (subprocess.CalledProcessError, FileNotFoundError):
            return {
                "success": False,
                "error": "Fabric CLI not found or not properly installed",
                "remediation": (
                    "Install Fabric CLI: https://github.com/microsoft/fabric-cli"
                ),
                "install_command": "pip install ms-fabric-cli",
            }

    def validate_authentication(self) -> Dict[str, Any]:
        """Validate Fabric authentication is working"""
        # Test with a simple command that requires auth
        # 'fab ls' lists workspaces
        command = ["ls"]
        result = self.cli._execute_command(command)

        if result.get("success"):
            return {"success": True, "message": "Authentication is working"}
        else:
            return {
                "success": False,
                "error": result.get("error", "Authentication failed"),
                "remediation": "Check FABRIC_TOKEN environment variable",
            }

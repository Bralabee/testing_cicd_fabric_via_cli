"""Packaged template resources."""
